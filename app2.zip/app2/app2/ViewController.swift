//
//  ViewController.swift
//  app2
//
//  Created by Adam Saher on 2019-09-06.
//  Copyright © 2019 adam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    var lbl_text = "Adam's"
    var buton_tabs = 0
    
    @IBOutlet weak var top_lbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        top_lbl.text = lbl_text
    }

    @IBAction func update_lbl(_ sender: UIButton) {
        buton_tabs += 1
        if top_lbl.text!.count > 30 { //! to deal with the null case
            top_lbl.text = "App"
        }
        top_lbl.text = top_lbl.text! + " app"
        //update_lbl(<#T##sender: UIButton##UIButton#>)
        
    }
    
    
}

