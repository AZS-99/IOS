//
//  ViewController.swift
//  app1
//
//  Created by Adam Saher on 2019-09-06.
//  Copyright © 2019 adam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    //variables
    var labelText = "App"
    
    //outlets
    @IBOutlet weak var top_lbl: UILabel!
    
    //lifecycle methods
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        print(#function)
        top_lbl.text = set_label_text(text: "Adam")
    }
    //Actions
    func set_label_text(text: String) -> String {
        return "The passed name was \(text)"
    }

}

