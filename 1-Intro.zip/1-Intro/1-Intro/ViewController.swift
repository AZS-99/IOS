//
//  ViewController.swift
//  1-Intro
//
//  Created by Adam Saher on 2019-09-07.
//  Copyright © 2019 Adam Saher. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    //variables are declared above the override fn
    @IBOutlet weak var top_lbl: UILabel!
    @IBOutlet weak var percent_lbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        percent_lbl.text = String(50)
    }

    //Actions are always under the override fn.
    //Select the slider, then from the Attribute Inspector on the left, set the min and max values.
    @IBAction func slider(_ sender: UISlider) {
        //sender here is an instance of the UISlider, and since we have only one slider in the project, Xcode
        //assumes this instance, sender, refers to the one nameless slider we have.
        percent_lbl.text = String(sender.value)
    }
    
}

