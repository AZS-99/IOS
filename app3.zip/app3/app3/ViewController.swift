//
//  ViewController.swift
//  app3
//
//  Created by Adam Saher on 2019-09-06.
//  Copyright © 2019 adam. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var slider_value: UILabel!
    
    
    @IBOutlet weak var the_slider: UISlider!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func slider_fn(_ sender: UISlider) {
        slider_value.text = String(format: "%1.2f", sender.value)
        update_background_colour(slider_value: slider_value?.value)
    }
    
    func update_background_colour(slider_value: Float) {
        self.view.backgroundColor = UIColor(red: (160/slider_value), green:(100/slider_value), blue: (20/slider_value))
    }
    
}

